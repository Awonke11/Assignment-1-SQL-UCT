-- Queation 1 : Show all information in the offices table. 
SELECT * FROM offices;