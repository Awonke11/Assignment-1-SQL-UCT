-- Question 2 : Show any 1 row in the orderDetails table (just one)
SELECT * 
FROM orderdetails
LIMIT 1;