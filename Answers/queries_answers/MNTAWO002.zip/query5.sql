-- Question 5 : What countries do the customers come from? Just show the country values
SELECT DISTINCT country
FROM customers;