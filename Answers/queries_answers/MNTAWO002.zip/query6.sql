-- Question 6 : Which cities are our offices in? Call the answer column city. 
SELECT DISTINCT city AS city
FROM offices;